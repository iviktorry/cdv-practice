function Hello()
{
  return <h1 className="text-3xl text-blue-500"> Hello</h1>
}
export default Hello;